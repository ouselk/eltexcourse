#!/usr/bin/env bash

SCRIPT_NAME="${0##*/}"

if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
	echo "я бригадир, сам не работаю"
	exit -1
fi

LOG="report_${SCRIPT_NAME}.log"
START=$(date +%s)
PID=$$

printf '%s [%d] Скрипт запущен!\n' "$(date '+%F %T')" "$PID" >> "$LOG"
ANSWER_FIFO="/tmp/cuckoo_reply_$PID.fifo"
mkfifo $ANSWER_FIFO

exec 3<>"$ANSWER_FIFO"

CUCKOO_PID=$(pgrep -f 'cuckoo.sh')
printf '%s[%d]: how much time do I have?\n' "$SCRIPT_NAME" "$PID" >> "/proc/$CUCKOO_PID/fd/3"

if read -r -t 10 ANSWER <&3; then
	if [[ "$ANSWER" =~ ^[0-9]+$ ]]; then
		sleep "$ANSWER"
	fi
fi

exec 3>&-
unlink "$ANSWER_FIFO"
END=$(date +%s)
RAZNICA=$((END - START))

printf '%s [%d] Скрипт завершился, работал %d секунд.\n' "$(date '+%F %T')" "$PID" "$RAZNICA" >> "$LOG"
exit 0
