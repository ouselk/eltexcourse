#!/usr/bin/env bash


CONFIG="./observer.conf"
LOG="./observer.log"

while true; do
	while read script; do
		found=0

		for proc in /proc/[0-9]*; do
			
			if tr '\0' '\n' 2>/dev/null < "$proc/cmdline" 2 | grep -qFx $script; then
				found=1
				break
			fi
		done

		if [[ "$found" -eq 0 ]]; then
			nohup bash "$script" 1>/dev/null 2>&1 &
			PID=$!
			printf '%s Перезапущен %s, PID=%d\n' "$(date '+%F %T')" "$scrpit" "$PID" >> "$LOG"
		fi
	done < "$CONFIG"
	sleep 1
done
