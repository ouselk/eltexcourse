#!/usr/bin/env bash
for arg in "$@"; do
    if [[ "$arg" == --pishitesuda=* ]]; then
        FIFO="${arg#--pishitesuda=}"
    fi
done

if [[ -z "$FIFO" ]]; then
	echo "Не указан параметр --pishitesuda"
	exit -1
fi

LOG="./cuckoo.log"

printf '%s Startup!\n' "$(date '+%F %T')" >> "$LOG"
shutdown() {
	printf '%s Shutdown!\n' "$(date '+%F %T')" >> "$LOG"
	exec 3>&-
	unlink "$FIFO"
	exit 0
}

trap shutdown SIGTERM SIGINT SIGQUIT

exec 3<> "$FIFO"
while (true); do
	request=""
	if ! read request <&3; then
		continue
	fi

	if [[ "$request" =~ ^([^[]+)\[([0-9]+)\]:[[:space:]]how[[:space:]]much[[:space:]]time[[:space:]]do[[:space:]]I[[:space:]]have\?$ ]]; then
		name="${BASH_REMATCH[1]}"
		pid="${BASH_REMATCH[2]}"
		n=$(( RANDOM % 9 + 2))

		printf '%s %s[%s] %s\n' \
			"$(date '+%F %T')" "$name" "$pid" "$n" >> "$LOG"
		
		reply="/tmp/cuckoo_reply_${pid}.fifo"
		if [[ -p "$reply" ]]; then
			printf '%s\n' "$n" > "$reply"
		else
			printf 'Не удалось ответить %s[%s]' "$name" "$pid"
		fi
	fi
done

shutdown()
